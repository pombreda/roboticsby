//-----------------------------------------------------------------------------
// File: DeviceID.cpp
// Copyright (c) 2006 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------



#include <windows.h>
#include <stdio.h>

int WINAPI WinMain(HINSTANCE hThisIns, HINSTANCE hLastIns, LPSTR lpszCmdLine, int nCmdShow){
	char string[1024];

	DISPLAY_DEVICE dev;
	dev.cb = sizeof(DISPLAY_DEVICE);
	int i = 0;
	while (EnumDisplayDevices(NULL, i, &dev, 0)){
		if (dev.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE){
			char *str = string + sprintf(string, "%s\n\n", dev.DeviceString);

			char *vendorID = strstr(dev.DeviceID, "VEN_");
			char *deviceID = strstr(dev.DeviceID, "DEV_");

			char *st = dev.DeviceID;
			while ((st = strchr(st, '&')) != NULL){
				*st = '\0';
				st++;
			}

			if (vendorID) str += sprintf(str, "VendorID: 0x%s\n", vendorID + 4);
			if (deviceID) str += sprintf(str, "DeviceID: 0x%s\n", deviceID + 4);

			MessageBox(NULL, string, "Device", MB_OK | MB_ICONINFORMATION);
			return 0;
		}
		i++;
	}

	MessageBox(NULL, "No primary device found", "Error", MB_OK | MB_ICONERROR);
	return -1;
}
