#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <dxerr.h>

int main()
{
	IDirect3D9* pD3D = Direct3DCreate9(D3D_SDK_VERSION);
	assert(pD3D);

	D3DADAPTER_IDENTIFIER9 adapter;
	pD3D->GetAdapterIdentifier(NULL, NULL, &adapter);	

	printf("Vendor: ");

	// determine vendor
	// Full list of vendors here: http://www.pcidatabase.com/vendors.php?sort=id
	switch(adapter.VendorId)
		{
		case 0x10DE:
			printf("NVIDIA\n");
			break;
		case 0x1002:
			printf("AMD\n");
			break;
		case 0x163C:
		case 0x8086:
			printf("INTEL\n");
			break;
		case 0x5333:
			printf("S3\n");
			break;
		case 0x3D3D:
			printf("3D LABS\n");
			break;
		case 0x102B:
			printf("MATROX\n");
			break;
		case 0x1039:
			printf("SIS\n");
			break;
		default:
			printf("UNKNOWN\n");
			break;
		};

	printf("Model: %s\n", adapter.Description);

	D3DCAPS9 capabilities;
	pD3D->GetDeviceCaps(NULL, D3DDEVTYPE_HAL, &capabilities);

	DWORD vsVersion = static_cast<DWORD>((capabilities.VertexShaderVersion & 0x0000FF00) >> 8);
	DWORD psVersion = static_cast<DWORD>((capabilities.PixelShaderVersion & 0x0000FF00) >> 8);

	printf("VS: %d; PS: %d\n", vsVersion, psVersion);

	return 0;
}